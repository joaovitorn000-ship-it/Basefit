# BaseFit — projeto do app Android (APK)

Este projeto empacota o BaseFit com o Capacitor e inclui a troca de ícone do app
(13 cores), que muda o ícone na tela inicial do celular de verdade.

## Gerar o APK sem Android Studio (pelo GitHub)
1. Crie uma conta grátis em github.com e um repositório novo (pode ser privado).
2. Envie todos os arquivos desta pasta para o repositório (Add file → Upload files).
   Se o celular não enviar a pasta oculta `.github`, crie o arquivo pelo site:
   Add file → Create new file, digite o nome `.github/workflows/build-apk.yml`
   e cole o conteúdo do arquivo `build-apk.yml` que está na raiz.
3. Abra a aba **Actions** → "Gerar APK do BaseFit" → **Run workflow**.
4. Espere uns 5 a 10 minutos. Ao terminar, abra a execução e baixe **BaseFit-APK**
   (em "Artifacts"). Dentro do zip está o `app-debug.apk`.
5. Instale o APK no Android (permita "instalar apps desconhecidos" quando o celular pedir).

## Como a troca de ícone funciona
- O app tem 13 "entradas de lançamento" (activity-alias), uma por cor. Só uma fica ativa.
- Em **Você → ⚙ → Personalizar logo → Aplicar logo**, o app liga a entrada da cor
  escolhida e desliga as outras (`IconSwitcherPlugin.java`).
- O Android/launcher pode levar alguns segundos para atualizar o ícone, e alguns
  celulares fecham o app ao trocar.

## Observações
- Este APK é de teste (assinado com a chave de debug). Para publicar na Google Play
  é preciso gerar um app assinado (AAB) com sua chave e criar a conta de desenvolvedor.
- O Bluetooth para monitor cardíaco não funciona dentro do APK (o WebView do Android
  não tem Web Bluetooth). A importação de .gpx/.tcx e o GPS funcionam.
- Se o build falhar, abra o log da execução em Actions e me envie a mensagem de erro.
