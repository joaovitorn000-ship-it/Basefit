package com.basefit.app;

import android.content.ComponentName;
import android.content.pm.PackageManager;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "IconSwitcher")
public class IconSwitcherPlugin extends Plugin {
    private static final String[] IDS = {
        "original", "rosa", "vermelha", "azul", "roxa", "verde", "laranja",
        "amarela", "ciano", "cinza", "gradiente", "dourada", "branca"
    };

    @PluginMethod
    public void setIcon(PluginCall call) {
        String id = call.getString("id");
        boolean valid = false;
        for (String s : IDS) if (s.equals(id)) valid = true;
        if (!valid) { call.reject("Ícone inválido"); return; }
        PackageManager pm = getContext().getPackageManager();
        String pkg = getContext().getPackageName();
        // ativa o novo ícone primeiro e só depois desativa os outros
        pm.setComponentEnabledSetting(new ComponentName(pkg, "com.basefit.app.Launcher_" + id),
            PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);
        for (String s : IDS) {
            if (s.equals(id)) continue;
            pm.setComponentEnabledSetting(new ComponentName(pkg, "com.basefit.app.Launcher_" + s),
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);
        }
        call.resolve();
    }
}
