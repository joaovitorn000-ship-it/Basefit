"""Ajusta o projeto Android gerado pelo Capacitor: ícones alternativos, permissões, splash e plugin."""
import re, glob, os, shutil, sys

IDS = ["original","rosa","vermelha","azul","roxa","verde","laranja","amarela","ciano","cinza","gradiente","dourada","branca"]
ROOT = sys.argv[1] if len(sys.argv) > 1 else "."
A = os.path.join(ROOT, "android/app/src/main")
M = os.path.join(A, "AndroidManifest.xml")

m = open(M, encoding="utf-8").read()
pat = re.compile(r'<intent-filter>\s*<action android:name="android\.intent\.action\.MAIN"\s*/>\s*<category android:name="android\.intent\.category\.LAUNCHER"\s*/>\s*</intent-filter>')
m, n = pat.subn("", m, count=1)
assert n == 1, "Não encontrei o filtro LAUNCHER no AndroidManifest.xml"

alias = ""
for i in IDS:
    alias += (f'\n        <activity-alias android:name=".Launcher_{i}" android:targetActivity=".MainActivity" '
              f'android:enabled="{"true" if i == "original" else "false"}" android:exported="true" '
              f'android:icon="@mipmap/ic_logo_{i}" android:roundIcon="@mipmap/ic_logo_{i}" android:label="BaseFit">'
              '<intent-filter><action android:name="android.intent.action.MAIN" />'
              '<category android:name="android.intent.category.LAUNCHER" /></intent-filter></activity-alias>')
assert "</application>" in m
m = m.replace("</application>", alias + "\n    </application>", 1)

perms = ""
for p in ("ACCESS_FINE_LOCATION", "ACCESS_COARSE_LOCATION"):
    if p not in m:
        perms += f'    <uses-permission android:name="android.permission.{p}" />\n'
m = m.replace("<application", perms + "    <application", 1)
open(M, "w", encoding="utf-8").write(m)

shutil.copytree(os.path.join(ROOT, "android-res"), os.path.join(A, "res"), dirs_exist_ok=True)

# splash preta com a logo (troca o splash padrão do Capacitor)
for f in glob.glob(os.path.join(A, "res/drawable*/splash.png")):
    os.remove(f)
os.makedirs(os.path.join(A, "res/drawable"), exist_ok=True)
open(os.path.join(A, "res/drawable/splash.xml"), "w").write(
    '<?xml version="1.0" encoding="utf-8"?>\n<layer-list xmlns:android="http://schemas.android.com/apk/res/android">\n'
    '  <item><shape android:shape="rectangle"><solid android:color="#000000"/></shape></item>\n'
    '  <item android:gravity="center" android:width="128dp" android:height="128dp"><bitmap android:src="@mipmap/ic_logo_original" android:gravity="fill"/></item>\n'
    '</layer-list>\n')

# plugin + MainActivity
jd = os.path.join(A, "java/com/basefit/app")
os.makedirs(jd, exist_ok=True)
for f in glob.glob(os.path.join(A, "java/**/MainActivity.java"), recursive=True):
    os.remove(f)
for f in ("MainActivity.java", "IconSwitcherPlugin.java"):
    shutil.copy(os.path.join(ROOT, "android-src", f), os.path.join(jd, f))
print("Projeto Android ajustado.")
